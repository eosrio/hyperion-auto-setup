#!/bin/bash

git clone https://github.com/eosrio/hyperion-history-api ~/hyperion || exit
cd ~/hyperion || exit
npm install
