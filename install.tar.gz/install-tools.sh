#!/bin/bash
sudo apt-get update
sudo apt-get install jq net-tools curl git
