#!/bin/bash

if [ "$(lsb_release -cs)" == "jammy" ]; then
  bash ./install-tools.sh
  bash ./install-elasticsearch.sh
  bash ./install-rabbitmq-jammy.sh
  bash ./install-redis.sh
else
  echo "Ubuntu 22.04 is required for auto install, for other distributions please install dependencies manually."
fi
